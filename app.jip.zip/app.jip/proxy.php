<?php

 session_start();
include 'pay/db.php';



$PHONE=$_GET['phone'];
$OTP=$_SESSION['OTP'];



$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}




$SMS_API=$data['sms_gateway'];


$URL="https://sms.renflair.in/V1.php?API=$SMS_API&PHONE=$PHONE&OTP=$OTP";
$curl=curl_init($URL);
curl_setopt($curl,CURLOPT_URL,$URL);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$resp=curl_exec($curl);
curl_close($curl);

// $data=json_decode($resp);


    header('Content-Type: application/json; charset=utf-8');
//  echo $data=json_decode($resp);   
// if($url=='SUCCESS' or $phone=='9876543210'){    
        
$data1['msg']="<h6 class='text-center text-secondary'>OTP has been sent to Your Phone Number </h6>";
$data1['status']="success";

// }else{
//     $data['msg']="<h6 class='text-center text-danger'>Wrong Whatsapp Number! Please input a valid whatsapp number 
// </h6>";
//      $data['status']="failed";
// }
$data1= json_encode($data1);

print_r($data1);

?>
