<?php
 session_start();
include 'pay/db.php';
$msg="OR";
if(isset($_POST['phone'])){
$phone=mysqli_real_escape_string($conn,$_POST['phone']);
$pass=mysqli_real_escape_string($conn,$_POST['pass']);

$sql="SELECT * FROM `user` WHERE userphone='$phone' AND auth='$pass'";
$qry=mysqli_query($conn,$sql);
$noof=mysqli_num_rows($qry);
if($noof>0){
   
    
    
	    $cookie_name="phone";
	    $cookie_value=$phone;
	    $domain=$_SERVER['SERVER_NAME'];
	    setcookie($cookie_name,$cookie_value,time()+(86400*365),"/$route",$domain);
		$_SESSION['login'] = $phone;
   
}else{
   	header("location:index.php?msg=Incorrect Login ID and Password <br> Wrong Credentials");
}
};
	if(isset($_SESSION['login'])){
	    
	    
    	header("location:location.php");
        };
        
  if(isset($_COOKIE['phone'])){
header("Location:location.php");}      
    ?>    