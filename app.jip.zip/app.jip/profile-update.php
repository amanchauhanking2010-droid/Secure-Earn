<?php

include 'pay/db.php';
session_start();

// Collect POST data
echo $name = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';
echo $address = $_POST['address'] ?? '';
$admin_id = $_POST['admin_id'] ?? '';
echo $uid = $_POST['uid'] ?? '';

// Validate required fields
// if (empty($name) || empty($phone) || empty($address) || empty($admin_id) || empty($uid)) {
//     die(json_encode([
//         'status' => 'error',
//         'message' => 'Missing required fields'
//     ]));
// }

// Prepare the cURL request
$update_url = "$base_url/profile-update.php"; // Replace with actual API endpoint

$data = [
    'name' => $name,
    'phone' => $phone,
    'address' => $address,
    'admin_id' => $admin_id,
    'uid' => $uid
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $update_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    $error_msg = curl_error($ch);
}
curl_close($ch);

if (isset($error_msg)) {
    echo json_encode([
        'status' => 'error',
        'message' => $error_msg
    ]);
    exit;
}

// Show the API response
echo $response; header("Location:home.php?lid=$lid");
?>



