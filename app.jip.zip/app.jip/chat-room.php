<?php

include 'pay/db.php';
session_start();
if(!isset($_COOKIE['phone'])){
header("Location:logout.php");}  

$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}


$appname=$data['app_name'];
$customer_support_whatsapp=$data['customer_support_whatsapp'];
$customer_support_phone=$data['customer_support_phone'];
$ananya=$appname;

$k['theme']=$data['theme_color'];
$k['btn-color']=$data['btn_color'];

$phone=$_COOKIE['phone'];

// Get user details
    $url = "$base_url/get-user-details.php?admin_id=$admin_id&phone=$phone";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
$data = json_decode($response, true);
if (isset($data['status']) && $data['status'] === 'success') {
    $uid = $data['data']['id'];
    $username = $data['data']['username'];
    $userphone = $data['data']['userphone'];

   
} else {
    echo "Error fetching user details";
}




                       
                        
?>

<!doctype html>
<html lang="en">



<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    
        <title><?php echo  $_COOKIE['user_id']; ?></title>
    <meta name="theme-color" content="<?php echo $ttt['theme']; ?>">
    <meta name="description" content="<?php echo $ttt['app_description']; ?>">
    <meta name="keywords" content="<?php echo $ttt['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $ttt['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
   
             <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap" rel="stylesheet">
 <!-- Font Awesome CDN (latest) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

        
          <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0px;
        }
        
    </style>
    
    
    
    <style>
b {text-align: center;}
p {text-align: center;}
h3 {text-align: left;}
div {text-align: center;}

.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1050; /* higher than Bootstrap modal */
    display: flex;
    justify-content: center;
    align-items: center;
}

.modal-content-center {
    background: white;
    padding: 20px;
    border-radius: 10px;
    width: 80%;
    max-width: 300px;
    text-align: center;
}



.code-box {
    background: #1e1e1e;
    color: #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    font-family: monospace;
    white-space: pre-wrap;
    overflow-x: auto;
}

</style>


  <style>
        
         #loaderr {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            display: none;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
            border-width: 0.3em;
        }
        
        
     
    </style>

</head>

<body class="bg-light">



<div style="background:<?php echo $k['theme']; ?>" class="appHeader" >

      <div class="left">
                 <a href="home.php" class="headerButton"  >
                <ion-icon name="chevron-back-outline" style="color:<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
            </div>
                <div class="pageTitle font-weight-bold"  style="color:<?php echo $k['btn-color']; ?>">
                 <?php echo $appname; ?>
                </div>
                <div class="right">
            <a href="profile.php?uid=<?php echo $uid; ?>&lid=<?php echo $lid; ?>" class="headerButton">
                <ion-icon name="person-outline" style="color:<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
        </div>
    </div>
    

    <!-- App Capsule -->
    <div id="appCapsule">

    <div id="uploadProgressModal" class="modal-overlay" style="display: none;">
    <div class="modal-content-center">
        <p>Uploading...</p>
        <div class="progress w-100">
            <div class="progress-bar" id="progress-bar" style="width: 0%;"></div>
        </div>
    </div>
</div>

        
         <!-- Share Action Sheet -->
    <div class="modal fade action-sheet inset" id="addActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Share</h5>
                </div>
                <div class="modal-body">
                    <ul class="action-button-list">
                     
                        <li>
                            <a href="#" id="upload-image" class="btn btn-list" data-dismiss="modal">
                                <span>
                                    <ion-icon name="image-outline"></ion-icon>
                                    Upload from Gallery
                                </span>
                            </a>
                             <input type="file" id="file-input" style="display: none;" accept="image/*">
                        </li>
                      
                    </ul>
                    
                
                </div>
            </div>
        </div>
    </div>
    <!-- * Share Action Sheet -->
        <style>
            #chats {
    max-height: 800px; /* Adjust as needed */
    overflow-y: auto;
}

        </style>
<div id="chats" class="mb-2" ></div></div>
    <!-- * App Capsule -->

  

    <!-- chat footer -->
    <div class="chatFooter mt-3">
    
              <a href="javascript:;" class="btn btn-icon  rounded" style="background:<?php echo $k['theme']; ?>"  style="color:<?php echo $k['btn-color']; ?>" data-toggle="modal" data-target="#addActionSheet">
                <ion-icon name="add"></ion-icon>
            </a>
            <div class="form-group boxed">
                <div class="input-wrapper">
                    <input type="hidden" class="form-control" id="room"  value="1" placeholder="Type a message...">
                     <input type="hidden" class="form-control" id="uid"  value="<?php echo $uid;?>" placeholder="Type a message...">
                     
                       <input type="text" class="form-control" id="msg"  placeholder="Type a message...">
                    <i class="clear-input">
                        <ion-icon name="close-circle"></ion-icon>
                    </i>
                </div>
            </div>
            <button type="submit" id="send" style="background:<?php echo $k['theme']; ?>" style="color:<?php echo $k['btn-color']; ?>" class="btn btn-icon  rounded">
                <ion-icon name="send"></ion-icon>
            </button>
       
       
       
       
       
       
    </div>
    
    
    
    
    
      <div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">

                    <!-- profile box -->
                    <div style="background:<?php echo $k['theme']; ?>"  class="profileBox">
                        <div class="image-wrapper">
                             <img src="https://www.awms-system.com/website/wp-content/uploads/2021/05/persone-al-centro.gif" alt="logo" width="50" height="50" class="rounded-circle border-dark">
                        </div>
                        <div class="in">
                            <?php
                            if(isset($_COOKIE['phone'])){
                            ?>
                             <strong class="text" style="color:<?php echo $k['btn-color']; ?>;"><i><?php echo $username?></i></strong>
                             <p class="text" style="color:<?php echo $k['btn-color']; ?>;">+91-<?php echo $phone?></p><?php }else{ ?>
                            <a href="index.php"> <button onclick="example1()" type="button" class="btn btn-dark btn-sm">Please Login</button></a>
                             <?php };?>
                        </div>
                        <p class="mt-0 mb-0" onclick="example1()"> 
                        <a href="javascript:;" class="close-sidebar-button" data-dismiss="modal">
                            <ion-icon name="close" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                        </a></p>
                    </div>
                    <!-- * profile box -->

                    <ul class="listview flush transparent no-line image-listview mt-2">
                        <li>
                            
                            <a href="home.php?lid=<?php echo $lid;?>" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="home-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                 
                                <div class="in">
                                    Home
                                </div>
                                
                            </a>
                        </li>
                        
                       
                     
                        <li>
                            <div class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="moon-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                <div class="in">
                                    <div>Dark Mode</div>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input dark-mode-switch"
                                            id="darkmodesidebar">
                                        <label class="custom-control-label" for="darkmodesidebar"></label>
                                    </div>
                                </div>
                            </div>
                        </li>
                  
                       <li>
                            <a href="about.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                   About Us
                                </div>
                            </a>
                        </li>
                         <li>
                            <a href="privacy-policy.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Privacy Policy
                                </div>
                            </a>
                        </li>
                        
                          <li>
                            <a href="terms.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Terms & Conditions
                                </div>
                            </a>
                        </li>
                        
                         <li>
                            <a href="delete-policy.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Account Delete Policy
                                </div>
                            </a>
                        </li>
                     
                        <li>
                            <a href="contactus.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                   Contact Us
                                </div>
                            </a>
                        </li>
                   
                        
                        <li>
                            <a href="logout.php" class="item">
                                <div  style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="log-out-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                <div class="in">
                                    Logout
                                </div>
                            </a>
                        </li>
                    </ul>
                <!-- sidebar buttons -->
                <div style="background:<?php echo $k['theme']; ?>" class="sidebar-buttons">
                  
                    <a href="tel:+91<?php echo $customer_support_phone;?>" class="button">
                        <ion-icon name="call-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                    </a>
                    <a href="https://api.whatsapp.com/send?phone=91<?php echo $customer_support_whatsapp;?>" class="button">
                        <ion-icon name="logo-whatsapp" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                    </a>
                
                </div>
                <!-- * sidebar buttons -->
                    
                
            </div>
        </div>
    </div>
    </div>
    <!-- * chat footer -->

    <!-- ///////////// Js Files ////////////////////  -->
  <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
<script src="assets/js/lib/popper.min.js"></script>
<script src="assets/js/lib/bootstrap.min.js"></script>
<script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
<script src="assets/js/base.js"></script>

<script>
    function scrollToBottom() {
        var chatsContainer = $("#chats");
        chatsContainer.scrollTop(chatsContainer.prop("scrollHeight"));
    }

    $(document).ready(function () {
        function loadChats() {
            $.ajax({
                url: "chats.php?id=<?php echo $uid; ?>",
                type: "GET",
                success: function (data) {
                    $("#chats").html(data);
                    scrollToBottom();
                }
            });
        }

        loadChats(); // Initial load

        $("#send").on("click", function (e) {
            e.preventDefault();
            var room = 1;
            var uid = $("#uid").val();
            var msg = $("#msg").val().trim();

            if (!msg) {
                alert("Message cannot be empty!");
                return;
            }

            // Append user's message immediately
            const userMessage = `
                <div class="message-item user">
                    <div class="content">
                        <div class="bubble text-right text-dark" style="background:<?php echo $k['theme']; ?>">
                            ${msg.replace(/\n/g, "<br>")}
                        </div>
                        <div class="footer">
                            <h6 style="font-size:7px;">Just now</h6>
                        </div>
                    </div>
                </div>`;
            $("#chats").append(userMessage);
            scrollToBottom();
            $('#msg').val('');

            // Add typing indicator
            const typingId = "typing-loader";
            const typingBubble = `
                <div class="message-item" id="${typingId}">
                    <div class="content">
                        <div class="bubble bg-light"><em><?php echo $ananya; ?> is typing...</em></div>
                    </div>
                </div>`;
            $("#chats").append(typingBubble);
            scrollToBottom();

            // Send to server
            $.ajax({
                url: "add.php",
                type: "POST",
                data: { room: room, uid: uid, msg: msg },
                success: function () {
                    // Wait 2-4 seconds then show response
                    setTimeout(() => {
                        $("#" + typingId).remove(); // remove typing
                        loadChats(); // get actual messages
                    }, 2000 + Math.random() * 2000);
                },
                error: function (xhr, status, error) {
                    console.error("Error sending message:", error);
                }
            });
        });

        // Allow Enter key to send
        $("#msg").on("keydown", function (e) {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                $("#send").click();
            }
        });

        // Periodic refresh for other messages
        setInterval(loadChats, 10000); // every 10 sec for fresh messages
    });
</script>

</body>

</html>
 
