(function () {
  // Read parameters from window._renflairChat
  const config = window._renflairChat || {};
  const phone = config.phone;
  const api = config.api;
  const buttonColor = config.buttonColor || "#5fb002";
  const buttonIcon = config.buttonIcon || null;

  if (!phone || !api) {
    console.error("Renflair Chat Widget: Missing 'phone' or 'api' in configuration.");
    return;
  }

  // Create the floating chat button
  const chatButton = document.createElement("button");
  chatButton.id = "chat-button";

  if (buttonIcon) {
    chatButton.innerHTML = `<img src="${buttonIcon}" alt="Chat" style="width: 100%; height: 100%; object-fit: contain;" />`;
  } else {
    chatButton.innerHTML = "";
  }

  // Style the button
  Object.assign(chatButton.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    zIndex: 9999,
    backgroundColor: buttonColor,
    color: "white",
    border: "none",
    borderRadius: "50%",
    width: "60px",
    height: "60px",
    fontSize: "28px",
    cursor: "pointer",
    boxShadow: "0 4px 10px rgba(0,0,0,0.3)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    padding: "0",
  });

  document.body.appendChild(chatButton);

  // Create the chat iframe (initially hidden)
  const iframe = document.createElement("iframe");
  iframe.id = "chat-window";
  iframe.style.display = "none";
  Object.assign(iframe.style, {
    position: "fixed",
    bottom: "90px",
    right: "20px",
    width: "350px",
    height: "500px",
    border: "none",
    zIndex: 9998,
    borderRadius: "12px",
    boxShadow: "0 0 20px rgba(0,0,0,0.3)",
  });

  document.body.appendChild(iframe);

  // Button click toggles iframe
  chatButton.addEventListener("click", function () {
    if (iframe.style.display === "none") {
      iframe.src = `https://www.renflairai.com/app/float.php?phone=${encodeURIComponent(phone)}&api=${encodeURIComponent(api)}`;
      iframe.style.display = "block";
    } else {
      iframe.style.display = "none";
    }
  });
})();
