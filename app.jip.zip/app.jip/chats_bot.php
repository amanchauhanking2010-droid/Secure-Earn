<?php

//include 'pay/db.php';
 $conn=mysqli_connect("localhost","aichatbot","7g5i4eQcNuNP1Z6MXsA1","aichatbot") or die("connection failed");
session_start();

$admin_id=mysqli_real_escape_string($conn, $_GET['admin_id']);;
$sql="SELECT * FROM `a_admins` where id='$admin_id'";
$qry=mysqli_query($conn,$sql);
$res=mysqli_fetch_assoc($qry);
$appname=$res['app_name'];
$customer_support_whatsapp=$res['customer_support_whatsapp'];
$customer_support_phone=$res['customer_support_phone'];

$k['theme']=$res['theme_color'];
$k['btn-color']=$res['btn_color'];


$uid=mysqli_real_escape_string($conn, $_GET['id']);


$k['theme']="#fcba03";
$sql78="UPDATE `chat` SET `green` = 'YES' WHERE seen='ADMIN' and `chat`.`user_id` = $uid;";
$qry78=mysqli_query($conn,$sql78);

?>
<div style="width:250 ;height:500 ;background:light " class="mb-2">
<?php 
$sql = "SELECT * FROM `chat` WHERE user_id='$uid' ORDER BY `chat`.`id` ASC ;";

$qry=mysqli_query($conn,$sql);
while($res=mysqli_fetch_array($qry)){ 
    $seen=$res['seen'];

?>
        

        
 
    <?php if($seen=='USER'){?>
<?php if($res['type']=='IMAGE'){ ?>

 
        
         <div class="message-item user" >
            <!--<img src="assets/img/sample/avatar/avatar2.jpg" alt="avatar" class="avatar">-->
            <div class="content" >
                <!--<div class="title">Marry</div>-->
                <div class="bubble bg-light" ><a href="<?php echo $res['url'];?>"> <img src="<?php echo $res['url'];?>" alt="photo" class="imaged w160"></a>
                   
                </div>
                <div class="footer "> <?php echo $res['dateandtime'];?></div>
            </div>
        </div>

<?php }else if($res['type']=='TEXT'){  ?>
 <div class="message-item user" >
            <div class="content">
                <div class="bubble text-right text-dark" style="background:<?php echo $k['theme']; ?>">
                   <?php echo $res['message'];?>
                </div>
                <div class="footer"> 
                <h6 style="font-size:7px; color:white;"> <?php echo $res['dateandtime'];?></h6>
                </div>
            </div>
        </div>
  

<?php }  ?>

 

       
    
    <?php }else{ ?>
    
    
    <?php if($res['type']=='IMAGE'){ ?>


          
        
         <div class="message-item">
          <!--<img src="https://cdn-icons-png.flaticon.com/512/10342/10342464.png" alt="avatar" class="avatar">-->
            <div class="content">
                <!--<div class="title">Marry</div>-->
                <div class="bubble">
                    <img src="https://renflair.in/ai/admin/<?php echo $res['url'];?>" alt="photo" class="imaged w160">
                </div>
                <div class="footer"><?php echo $res['datandtime'];?></div>
            </div>
        </div>

<?php }else{  ?>
    <div class="message-item">
         
            <div class="content">
                <!--<div class="title">Marry</div>-->
<?php
$message = $res['message'];
$is_code = false;

// Simple detection of code (you can make it more complex if needed)
if (strpos($message, "```") !== false || strpos($message, "<?php") !== false || preg_match('/function\s+\w+\s*\(/', $message)) {
    $is_code = true;
    // Strip triple backticks if present
    $message = str_replace("```", "", $message);
}
?>

<?php if ($is_code): ?>
    <div class="bubble text-left" style="background:#1e1e1e; color:#fffafa; padding:10px; border-radius:8px; font-family:monospace; white-space:pre-wrap; overflow-x:auto;">
        <code><?php echo nl2br(htmlspecialchars($message)); ?></code>
    </div>
<?php else: ?>
    <div class="bubble text-left">
       <?php echo nl2br($message); ?>
    </div>
<?php endif; ?>


                <div class="footer">
                    <h6 style="font-size:7px; color:white;"> <?php echo $res['datandtime'];?></h6>
                    </div>
            </div>
        </div>
        
         <?php }; ?>
         
         
         
        <?php }; ?>
    <?php }; ?>
 </div>   
    