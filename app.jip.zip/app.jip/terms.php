<?php
 include 'pay/db.php';


if(isset($_COOKIE['admin_id'])){
$admin_id=$_COOKIE['admin_id'];
}else{
 $admin_id=$_GET['id']; 
}

$sql="SELECT * FROM `a_admins` where id='$admin_id'";
$qry=mysqli_query($conn,$sql);
$res=mysqli_fetch_assoc($qry);
$appname=$res['app_name'];
$customer_support_phone=$res['customer_support_phone'];
$k['theme']=$res['theme_color'];
$k['btn-color']=$res['btn_color'];
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo $appname; ?> - Terms & Conditions</title>
    <meta name="theme-color" content="<?php echo $k['theme']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    <?php if ($k['theme_type'] == 'ADVANCE') { ?>
        <div style="background:<?php echo $k['theme']; ?>" class="appHeader rounded-pill mt-1 ml-1 mr-1 mb-1">
    <?php } else { ?>
        <div style="background:<?php echo $k['theme']; ?>" class="appHeader">
    <?php } ?>
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
        </div>
        <div class="pageTitle text-<?php echo $k['btn-color']; ?>">Terms & Conditions</div>
        <div class="right"></div>
    </div>

    <div id="appCapsule">
        <div class="section full mt-2">
            <div class="wide-block pt-2 pb-2">

                <h2>Terms & Conditions</h2>
                <p>Effective Date: <?php echo date("F d, Y"); ?></p>

                <p>Welcome to <strong><?php echo $appname; ?></strong> ("we", "our", "us"). These Terms & Conditions ("Terms") govern your use of our food and grocery delivery application and services.</p>

                <h4>1. Acceptance of Terms</h4>
                <p>By accessing or using our app, you agree to be bound by these Terms. If you do not agree, please do not use our services.</p>

                <h4>2. User Responsibilities</h4>
                <ul>
                    <li>You must provide accurate and complete information during sign-up.</li>
                    <li>You are responsible for maintaining the confidentiality of your account and password.</li>
                    <li>You agree not to misuse or attempt to disrupt the service.</li>
                </ul>

                <h4>3. Orders & Deliveries</h4>
                <ul>
                    <li>Once an order is placed, it cannot be cancelled after preparation begins.</li>
                    <li>Delivery times may vary based on location and availability.</li>
                    <li>In case of delivery failure due to incorrect information, the payment will not be refunded.</li>
                </ul>

                <h4>4. Payments</h4>
                <ul>
                    <li>We accept various payment methods including COD, UPI, and wallet payments.</li>
                    <li>All transactions are secure and encrypted.</li>
                    <li>In case of failed payment, your order will not be processed.</li>
                </ul>

                <h4>5. Refunds & Cancellations</h4>
                <p>Refunds are applicable only in the following cases:</p>
                <ul>
                    <li>Order not delivered due to internal issues.</li>
                    <li>Item is unavailable and payment was already made.</li>
                </ul>

                <h4>6. Limitation of Liability</h4>
                <p>We are not liable for any indirect or consequential damages arising from the use of our services.</p>

                <h4>7. Updates to Terms</h4>
                <p>We reserve the right to modify these Terms at any time. Changes will be notified within the app and effective immediately.</p>

                <h4>8. Contact Information</h4>
                <p>If you have questions about these Terms, contact us at:</p>
                <p>📧 <strong>support.<?php echo strtolower($appname); ?>@gmail.com</strong></p>

                <p class="mt-4 text-muted">Thank you for using <?php echo $appname; ?>. Enjoy your experience! 🚀</p>

            </div>
        </div>
    </div>

  

    <!-- JS Files -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
    <script src="assets/js/base.js"></script>

</body>

</html>
