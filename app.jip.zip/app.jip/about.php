<?php
 include 'pay/db.php';

if(isset($_COOKIE['admin_id'])){
$admin_id=$_COOKIE['admin_id'];
}else{
 $admin_id=$_GET['id']; 
}

$sql="SELECT * FROM `a_admins` where id='$admin_id'";
$qry=mysqli_query($conn,$sql);
$res=mysqli_fetch_assoc($qry);
$appname=$res['app_name'];
$customer_support_phone=$res['customer_support_phone'];
$k['theme']=$res['theme_color'];
$k['btn-color']=$res['btn_color'];
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo $appname; ?> - About Us</title>
   <meta name="theme-color" content="<?php echo  $res['theme_color']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    
        <div style="background:<?php echo $k['theme']; ?>" class="appHeader">

        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
        </div>
        <div class="pageTitle " style='color:<?php echo $k['btn-color']; ?>'>About Us</div>
        <div class="right"></div>
    </div>

    <div id="appCapsule">
        <div class="section full mt-2">
            <div class="section-title"></div>
            <div class="wide-block pt-2 pb-2">
                <h2>Welcome to <?php echo $appname; ?>!</h2>
                <p>
                    <?php echo $appname; ?> is your go-to food delivery app, built to bring your favorite meals from local restaurants right to your doorstep, fast and fresh. Whether you're craving comfort food, a healthy salad, or late-night snacks, we’ve got you covered.
                </p>

                <h4>Our Mission</h4>
                <p>
                    Our mission is simple — to deliver happiness in every bite. We aim to provide a seamless ordering experience, timely deliveries, and the best offers to ensure your satisfaction every time.
                </p>

                <h4>Why Choose Us?</h4>
                <ul>
                    <li>🚀 Super-fast delivery</li>
                    <li>🍱 A wide range of restaurants & cuisines</li>
                    <li>💳 Multiple secure payment options</li>
                    <li>📍 Real-time order tracking</li>
                    <li>🛡️ Safe and hygienic packaging</li>
                </ul>

                <h4>Our Team</h4>
                <p>
                    We’re a passionate team of food lovers, tech innovators, and customer service pros committed to making your food experience better each day.
                </p>

                <h4>Get in Touch</h4>
                <p>
                    Have questions or suggestions? We’d love to hear from you!
                    <br>
                    📧 <strong>support.<?php echo strtolower($appname); ?>@gmail.com</strong><br>
                  Phone: <strong>support.<?php echo $customer_support_phone; ?></strong>
                </p>

                <p class="mt-4 text-muted">
                    Thank you for choosing <?php echo $appname; ?>. Bon appétit! 🍔🍕🍜
                </p>
            </div>
        </div>
    </div>

  
    <!-- Scripts -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
    <script src="assets/js/base.js"></script>

</body>

</html>
