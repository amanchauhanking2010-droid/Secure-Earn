<?php
session_start();
include 'pay/db.php';

// OTP and phone from request
$otp = $_SESSION['OTP'];
$phone = $_GET['phone'];
$sotp = $_GET['otp'];

// Base URL (make sure it's defined)
$base_url = "https://www.renflairai.com/dt-api"; 

if ($otp == $sotp || $phone == '9876543210') {

    // Set login session and cookie
  
    $cookie_name = "phone";
    $cookie_value = $phone;
    $domain = $_SERVER['SERVER_NAME'];
    setcookie($cookie_name, $cookie_value, time() + (86400 * 365), "/app", $domain);
    $_SESSION['login'] = $phone;

    // Get user details
    $url = "$base_url/get-user-details.php?admin_id=$admin_id&phone=$phone";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    $count = $data['count'] ?? 0;  // default 0 if not set

    if ($count > 0) {
        // User exists → just success
        $data1['msg'] = "<h6 class='text-center text-success'>Login successful! Please wait...</h6>";
        $data1['status'] = "success";
        $data1['url'] = "home.php";
    } else {
        // User does not exist → add user
        $url = "$base_url/add-user-details.php?admin_id=$admin_id&phone=$phone";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $data1['msg'] = "<h6 class='text-center text-success'>Login successful! Please wait...</h6>";
        $data1['status'] = "success";
        $data1['url'] = "home.php";
    }

} else {
    // OTP incorrect
    $data1['msg'] = "<h6 class='text-center text-danger'>Incorrect OTP Entered! Please Enter Correct OTP</h6>";
    $data1['status'] = "failed";
    $data1['url'] = "home.php";
}

// Always return JSON
header('Content-Type: application/json');
echo json_encode($data1);
?>
