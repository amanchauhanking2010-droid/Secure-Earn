<?php 
 session_start();
include 'pay/db.php';


$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}




$otp_length=$data['otp_length'];
if(isset($_GET['onesignal_id'])){
  $_SESSION['ONESIGNAL']=$_GET['onesignal_id'];  
}

$token=$_SESSION['ONESIGNAL'];


         $cookie_name="onesignal_id";
	    $cookie_value=$token;
	    $domain=$_SERVER['SERVER_NAME'];
	    setcookie($cookie_name,$cookie_value,time()+(86400*365),"",$domain);





$msg=$_GET['msg'];
if($otp_length=='4'){
$otp1=rand(1111,9999);    
}else if($otp_length=='6'){
$otp1=rand(111111,999999);    
}

$_SESSION['OTP']=$otp1;

$otp=123456;
  if(isset($_COOKIE['phone'])){
header("Location:home.php");}      
        
	?>



<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
     
        <title><?php echo  $data['admin_name']; ?>-Login Page</title>
    <meta name="theme-color" content="<?php echo  $res['theme_color']; ?>">
   
    <meta name="keywords" content="<?php echo $ttt['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $ttt['fav_icon']; ?>" sizes="32x32">
      <!-- Slick Slider -->
      <link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css"/>
      <link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css"/>
      <!-- Feather Icon-->
      <link href="vendor/icons/feather.css" rel="stylesheet" type="text/css">
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Sidebar CSS -->
      <link href="vendor/sidebar/demo.css" rel="stylesheet">
      <!-- Flag Mobile Number -->
      <link rel="stylesheet" href="vendor/build/css/intlTelInput.css">
      <link rel="stylesheet" href="vendor/build/css/demo.css">
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap" rel="stylesheet">
      
    <link rel="manifest" href="https://invikta.in/app/manifest.json">



         <style>
        body {
             font-family: 'Montserrat', sans-serif;
            background-color: #ffffff;
        }
      
h2 {text-align: center;}
p {text-align: center;}
.inp{
    height:50px;
    font-size:20px;
    border-radius:15px;
}
.loginbg{
    margin-top:60px;
    /*margin-left:3px;*/
     margin-right:0px;
    border-radius:40px 40px 0px 0px; 
    padding:20px;
   height:500px; 
   width:auto;
   background: <?php echo  $data['theme_color']; ?>;
   border-color:black;
}
.loginbtn{
    margin-top:25px;  
   height:50px;
   border-radius:15px;
   background: black;
}
.logo{
 margin-top:15px;
 display: flex;
 justify-content: center;
 align-items: center;
}
.messagebox{
     margin-top:50px;
 /*display: flex;*/
 /*justify-content: center;*/
 /*align-items: center;*/
}
</style>
   </head>
   <body style="background:#ffffff">
      <div class="osahan-signup login-page" style="background:#ffffff" >
         <div class="vh-10">
            <div class="">
              <div style="text-align: center; margin-top: 40px; font-size:20px;">
              Welcome to <?php echo  $data['app_name']; ?>   
              </div><br><br>
              
           <div class="logo">
               <img src="<?php echo  $data['app_logo']; ?>" height="200" width="200" class="rounded" style="object-fit: contain;"> 
               
               
           </div><br>
           
           
            <style>
         #loaderr {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            display: none;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
            border-width: 0.3em;
        }
    </style> 
           
           	<div id="loaderr" style="display:none;">
            <div class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
    </div>
           
               <div class="loginbg  ">
                   <p style="color:<?php echo $data['btn_color']; ?>;"> Enter your mobile number to Signup or login</p><br>
              <form id="loginForm" >
                <div id="phoneInput" class="mt-3">
                     <div  class="mt-3">
                    <input type="number" placeholder="    Enter Mobile Number" name="phone" id="iphone" class="inp mt-3 form-control form-control-lg border-1 border-dark" required>
                    
                     <button type="button" id="nbtn" onclick="sendOTP()" class="btn btn-dark btn-lg btn-block loginbtn">
                    <img src="https://cdn-icons-png.flaticon.com/512/891/891399.png" alt=""><h5>Continue</h5>
                </button>
                  
                </div>
            
                <div id="otpInput" class="mt-3" style="display:none;">
                    <input type="number" placeholder="Enter OTP" name="otp" id="otp" class="inp mt-3 form-control form-control-lg border-0" required>
                </div>
            
                <button id="submitButton" class="btn btn-dark btn-lg btn-block loginbtn" type="button" style="display:none;">
                    <img src="https://cdn-icons-png.flaticon.com/512/891/891399.png" alt=""><h5> Verify OTP</h5>
                </button>
                <div style="font-size:15px; color:white; text-align:center; margin-top:10px;" id="timer"></div><div id="resend" style="display:none; font-size:17px; color:white; text-align:center; margin-top:10px;" onclick="resendOTP()">Resend OTP</div>
             <div id="msg" class="mt-3"></div>
                <div class="messagebox">
               

<br><br><br><div class="text-center text mt-1 mb-2" style="margin-top: 20px; font-size: 15px;; text-align:center; color:<?php echo $res['btn_color']; ?>;">
            By continuing, you agree to our <a href="#"  style="color: <?php echo $res['btn_color']; ?>; text-decoration: none;"><b>Terms of Use</b></a> & <a href="#" style="color: <?php echo $res['btn_color']; ?>; text-decoration: none;"><b>Privacy Policy</b></a>
        </div>

               
                </div>
                
            </form>
                 

                 <!--<div class="mb-3">-->
                     <!--<div class="row">-->
                         
                     <!--   <div class="col-6 pr-1">-->
                     <!--        <a href="./shop/" class="btn btn-lg btn-light btn-block">-->
                          
                     <!--      <img src="https://cdn-icons-png.flaticon.com/512/7557/7557938.png" alt=""> Seller Login-->
                     <!--     </a>-->
                     <!--   </div>-->
                     <!--   <div class="col-6 pl-1">-->
                     <!--       <a href="./dboy/" class="btn btn-lg btn-light btn-block">-->
                           
                     <!--      <img src="https://cdn-icons-png.flaticon.com/512/2331/2331708.png" alt="">Rider Login-->
                     <!--     </a>-->
                     <!--   </div>-->
                     <!--</div>-->
                  <!--</div> <br><br><br>  <br><br> <br><br>  <br><br> -->
            </div>
           </div>
         </div>
      </div>
   
      
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- slick Slider JS-->
      <script type="text/javascript" src="vendor/slick/slick.min.js"></script>
      <!-- Sidebar JS-->
      <script type="text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>
      <!-- Flag Number-->
      <script src="vendor/build/js/intlTelInput.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="js/osahan.js"></script>
      <script>
      
     

     
   
      function vib() {
             // Vibrate for 500ms
             navigator.vibrate([500]);
          }
          
           function vibless() {
             // Vibrate for 500ms
             navigator.vibrate([50]);
          }
      
    function sendOTP() {
        
        document.getElementById('loaderr').style.display = 'block';
    var phone = document.getElementById('iphone').value;
    var otp = <?php echo $otp; ?>; // You need to define the generateOTP() function
  $("#otpInput").val(''); 
  
   if (!phone.trim()) {
       $("#msg").html('<p style="font-size:15px; color:red; text-align:center; margin-top:10px;">Please enter a valid phone number</p>'); 
       
        return; // Stop further execution
    } else if (phone.trim().length < 10) {
       
        $("#msg").html('<p style="font-size:15px; color:red; text-align:center; margin-top:10px;">Phone number must be at least 10 digits long</p>'); 
        return; // Stop further execution
    }else if (phone.trim().length > 10) {
       
        $("#msg").html('<p style="font-size:15px; color:red; text-align:center; margin-top:10px;">Phone number must be at least 10 digits long</p>'); 
        return; // Stop further execution
    }
  // Start the timer
    amit();
  <?php  $otp=1234; ?>
    // Use your proxy server to make the API request
    $.ajax({
        url: 'proxy.php?phone=' + phone + '&otp=' + otp,
        type: 'GET',
        success: function (data) {
            // Handle the response as needed
            console.log(data['status']);
             var stat = data['status'];
             var msg = data["msg"];
              $("#msg").html(msg);
              
              if(stat=="failed"){
                 $("#msg").html(data["msg"]);
                 vib();
                
              }else{
                //   vibless();
                $("#msg").html(msg); 
               
              document.getElementById('iphone').style.display = 'none';
            document.getElementById('nbtn').style.display = 'none';
            document.getElementById('otpInput').style.display = 'block';
            document.getElementById('submitButton').style.display = 'block'; 
            document.getElementById('loaderr').style.display = 'none';
              }
        },
        error: function (error) {
            // Handle errors
            console.error(error);
        }
    });
}

$("#submitButton").on("click", function(e) {
    e.preventDefault();
    var phone = $("#iphone").val();
    var otp = $("#otp").val();
    
    // Show loader
    $("#loaderr").show();

    $.ajax({
        url: "verify.php",
        type: "GET",
        data: { phone: phone, otp: otp },
        dataType: "json", // <-- tell jQuery to expect JSON
        success: function(json) {
            console.log("Response JSON:", json);

            // Update message
            $("#msg").html(json.msg);

            if(json.status === "failed") {
                vib(); // vibration or alert function
                $("#loaderr").hide();
            } else if(json.status === "success") {
                $("#loaderr").hide();
                setTimeout(function() {
                    window.location.href = json.url || "home.php";
                }, 1000);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", error);
            $("#msg").html("<h6 class='text-center text-danger'>Server error. Please try again.</h6>");
            $("#loaderr").hide();
        }
    });
});


        
   
</script>


<script>


// Function to handle Resend action
function resendOTP() {
    // Reset timer
    document.getElementById('timer').textContent = '30';
    
    // Show the timer
    document.getElementById('timer').style.display = 'block';
    
    // Hide Resend button
    document.getElementById('resend').style.display = 'none';
    
    // Reset OTP input
    document.getElementById('otpInput').style.display = 'none';
    document.getElementById('otpInput').value = '';
    
    // Show phone input
    document.getElementById('iphone').style.display = 'block';
    document.getElementById('nbtn').style.display = 'none';
    
    // Call sendOTP function again
    sendOTP();
}
function amit(){
    var timer = 30; // Set the timer duration in seconds
    var display = document.getElementById('timer');
    
    var intervalId = setInterval(function () {
        timer--;
        display.textContent = timer < 10 ? "0" + timer : timer; // Format the timer to display leading zero
         if (timer <= 0) {
            clearInterval(intervalId); // Stop the timer
            document.getElementById('resend').style.display = 'block'; // Show the Resend button
            display.textContent = "Resend in 30 Seconds"; // Change text to indicate resend after 30 seconds
        } else {
            display.textContent = "Resend in " + timer + " Seconds"; // Display countdown
        }
        if (timer <= 0) {
            clearInterval(intervalId); // Stop the timer
            document.getElementById('resend').style.display = 'block'; // Show the resend button
            document.getElementById('timer').style.display = 'none'; // Hide the timer
        }
    }, 1000);
}
</script>


   </body>
</html>