<?php
 include 'pay/db.php';
if(!isset($_COOKIE['phone'])){
    header("location:index.php");
}

if(isset($_COOKIE['admin_id'])){
$admin_id=$_COOKIE['admin_id'];
}else{
 $admin_id=$_GET['id']; 
}

$sql="SELECT * FROM `a_admins` where id='$admin_id'";
$qry=mysqli_query($conn,$sql);
$res=mysqli_fetch_assoc($qry);
$appname=$res['app_name'];
$customer_support_phone=$res['customer_support_phone'];
$k['theme']=$res['theme_color'];
$k['btn-color']=$res['btn_color'];
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo $appname; ?> - Delete Policy</title>
    <meta name="theme-color" content="<?php echo $k['theme']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    <?php if ($k['theme_type'] == 'ADVANCE') { ?>
        <div style="background:<?php echo $k['theme']; ?>" class="appHeader rounded-pill mt-1 ml-1 mr-1 mb-1">
    <?php } else { ?>
        <div style="background:<?php echo $k['theme']; ?>" class="appHeader">
    <?php } ?>
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
        </div>
        <div class="pageTitle text-<?php echo $k['btn-color']; ?>">Account Delete Policy</div>
        <div class="right"></div>
    </div>

     <div id="appCapsule">
       <div class="section full mt-2">
    <div class="wide-block pt-2 pb-2">
        <h2>🔒 Account Deletion Policy</h2>
        <p>Your privacy and control over your personal data are important to us. If you wish to delete your account on <strong><?php echo $appname; ?></strong>, we provide a simple and secure process.</p>

        <h4 class="mt-4">📩 How to Request Account Deletion</h4>
        <p>You can  delete your account by clicking Delete account permenantely Button:</p>
        

        <h4 class="mt-4">🕒 Deletion Timeframe</h4>
        within 7 days auto delete Account or u can click Permenantly Delete Button to Delete Account Immidiately.<br>
        <a href="#" class="btn btn-danger m-2">Permanently Delete Account</a>
        <p>
            Once you click your account will deleted . All your personal information including name, phone number, address, and order history will be permanently deleted from our system.
        </p>

        <h4 class="mt-4">⚠️ Important Notes</h4>
        <ul>
            <li>This action is <strong>irreversible</strong>.</li>
            <li>Once deleted, your data cannot be recovered.</li>
            <li>Make sure to clear any remaining balance in your wallet before submitting a deletion request.</li>
        </ul>

        <p class="mt-4 text-muted">Thank you for being a part of <strong><?php echo $appname; ?></strong>. Your trust matters to us. 💚</p>
    </div>
</div>

    </div>

  

    <!-- JS Files -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
    <script src="assets/js/base.js"></script>

</body>

</html>
