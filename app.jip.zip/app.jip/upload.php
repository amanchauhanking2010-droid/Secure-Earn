<?php
session_start();
$conn=mysqli_connect("localhost","u812957029_code","Shraboni@7797461382","u812957029_code") or die("connection failed");

$uid=$_COOKIE['id'];



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    // Database connection
    $host = 'localhost'; // Change to your database host
    $db = 'u812957029_code'; // Change to your database name
    $user = 'u812957029_code'; // Change to your database username
    $pass = 'Shraboni@7797461382'; // Change to your database password

    try {
        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Handle file upload
        $uploadDir = 'chat-images/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $fileName = basename($_FILES['image']['name']);
        $targetFilePath = $uploadDir . $fileName;
        $imageUrl = $targetFilePath; // URL to store in the database


 date_default_timezone_set('Asia/Kolkata');
$time=date("h:i:sa");
$dd=date("d");
$mm=date("m");
$yy=date("Y");
$dateandtime=date("d-m-Y h:i:s");
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath)) {
            // Insert into database
            $sql = "INSERT INTO `chat` (`id`, `user_id`, `room`, `message`, `seen`, `datandtime`, `green`, `type`, `url`) 
                    VALUES (NULL, :user_id, :room, '', 'USER', '$dateandtime', 'NO', 'IMAGE', :url)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':user_id' => $uid, // Replace with actual user ID
                ':room' => 1,    // Replace with actual room ID
                ':url' => $imageUrl
            ]);

            echo json_encode(['status' => 'success', 'path' => $imageUrl]);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Failed to move uploaded file.']);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>
