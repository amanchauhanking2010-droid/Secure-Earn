<?php 


$uri=$_SERVER['HTTP_HOST'];
$route="app";


$user_app_id="ab67e593-f0af-42c6-bb96-1fd91696fa3f";
$user_rest_api="ZTdkOWRkOWUtYTZlYy00N2M3LWI2MDQtYjBlZmNmMDJiYmJl";
$user_channel_id="5626e1b8-029e-4e8f-8e2d-506065144eb4";


$phone=$_COOKIE['phone'];

$base_url="https://www.renflairai.com/dt-api";
$api_key="4";
$admin_id=$api_key;
?>