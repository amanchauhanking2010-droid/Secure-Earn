<?php 
include 'pay/db.php';
unset($_COOKIE['phone']);
 $cookie_name="phone";
	    $cookie_value="";
	    $domain=$_SERVER['SERVER_NAME'];
	    setcookie($cookie_name,$cookie_value,time()+3600,"/app",$domain);
session_start();

$admin_id=$_COOKIE['admin_id'];
 $cookie_name="admin_id";
	    $cookie_value="";
	    $domain=$_SERVER['SERVER_NAME'];
	    setcookie($cookie_name,$cookie_value,time()+3600,"/app",$domain);
	    
	     $cookie_name = "user_id";
    $cookie_value = '';
    $domain = $_SERVER['SERVER_NAME'];
    setcookie($cookie_name, $cookie_value, time() - (86400 * 365), "", $domain);
session_start();

session_destroy();
unset($_COOKIE['phone']);
unset($_COOKIE['admin_id']);

   header("Location:index.php?id=$admin_id"); 



?>