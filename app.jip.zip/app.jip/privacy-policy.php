<?php
 include 'pay/db.php';
if(isset($_COOKIE['admin_id'])){
$admin_id=$_COOKIE['admin_id'];
}else{
 $admin_id=$_GET['id']; 
}


$sql="SELECT * FROM `a_admins` where id='$admin_id'";
$qry=mysqli_query($conn,$sql);
$res=mysqli_fetch_assoc($qry);
$appname=$res['app_name'];
$customer_support_phone=$res['customer_support_phone'];
$k['theme']=$res['theme_color'];
$k['btn-color']=$res['btn_color'];
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo $appname; ?></title>
    <meta name="theme-color" content="<?php echo $k['theme']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
    <style>
        .policy-content h4 {
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }

        .policy-content p {
            font-size: 15px;
            line-height: 1.7;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

    <!-- App Header -->
   
            <div style="background:<?php echo $k['theme']; ?>" class="appHeader">
         

            <div class="left">
                <a href="javascript:;" class="headerButton goBack">
                    <ion-icon name="chevron-back-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                </a>
            </div>
            <div class="pageTitle text-<?php echo $k['btn-color']; ?>">Privacy Policy</div>
            <div class="right"></div>
            </div>
            <!-- * App Header -->

            <!-- App Capsule -->
            <div id="appCapsule">
                <div class="section full mt-2">
                    <div class="wide-block pt-2 pb-2 policy-content">
                        <h4>Privacy Policy</h4>
                        <p><strong>Effective Date:</strong> <?php echo date("F d, Y"); ?></p>

                        <p>Welcome to <strong><?php echo $appname; ?></strong> ("we", "our", or "us"). Your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your information when you use our application.</p>

                        <h4>1. Information We Collect</h4>
                        <p>When you use <strong><?php echo $appname; ?></strong>, we may collect the following personal information:</p>
                        <ul>
                            <li>Name</li>
                            <li>Phone number</li>
                            <li>Address</li>
                            <li>Landmark (optional)</li>
                        </ul>

                        <h4>2. How We Use Your Information</h4>
                        <p>We use the collected data to:</p>
                        <ul>
                            <li>Fulfill and manage your orders</li>
                            <li>Provide customer support</li>
                            <li>Improve our services</li>
                            <li>Communicate with you about your account or orders</li>
                        </ul>

                        <h4>3. Data Sharing and Disclosure</h4>
                        <p>We <strong>do not sell, rent, or share your personal data</strong> with any third party. Your data is used strictly to deliver services through <strong><?php echo $appname; ?></strong>.</p>

                        <h4>4. Data Security</h4>
                        <p>We use appropriate security measures to protect your data. While we aim to use commercially acceptable means, no method is 100% secure.</p>

                        <h4>5. Children's Privacy</h4>
                        <p>This app is not intended for children under the age of 13. We do not knowingly collect personal data from children.</p>

                        <h4>6. Your Consent</h4>
                        <p>By using <strong><?php echo $appname; ?></strong>, you consent to this Privacy Policy and agree to its terms.</p>

                        <h4>7. Changes to This Policy</h4>
                        <p>We may update our Privacy Policy from time to time. Any changes will be reflected on this page with the updated date.</p>

                        <h4>8. Contact Us</h4>
                        <p>If you have any questions or concerns, please contact us at:</p>
                        <p><strong>Email:</strong> support.<?php echo strtolower($appname); ?>@gmail.com</p>
                    </div>
                </div>
            </div>
            <!-- * App Capsule -->

            <?php
            // The bottom menu remains unchanged
            ?>
           
                    <!-- Scripts -->
                    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
                    <script src="assets/js/lib/popper.min.js"></script>
                    <script src="assets/js/lib/bootstrap.min.js"></script>
                    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
                    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
                    <script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
                    <script src="assets/js/base.js"></script>
</body>

</html>
