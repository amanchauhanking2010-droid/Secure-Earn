<?php 
 session_start();
include 'pay/db.php';
$msg="";

if(isset($_POST['otpsend'])){
 $phone=mysqli_real_escape_string($conn,$_POST['phone']);
$pass=mysqli_real_escape_string($conn,$_POST['pass']);   
$name=mysqli_real_escape_string($conn,$_POST['name']); 
$long=mysqli_real_escape_string($conn,$_POST['long']); 
$lat=mysqli_real_escape_string($conn,$_POST['lat']); 
$_SESSION['ph']=$phone;

$sql0="SELECT * FROM `user` WHERE userphone=$phone";
$qry0=mysqli_query($conn,$sql0);
$noof=mysqli_num_rows($qry0);
if($noof>0){
    $msg="User Already Registered";
}else{
if($RESAPI['STATUS']=='ENABLE'){   
$PHONE=$phone;
$OTP=$_SESSION['SOTP'];
$REQUEST_URI="https://sms.renflair.in/V1.php?";
$URL="https://sms.renflair.in/V1.php?API=$API&PHONE=$PHONE&OTP=$OTP";
$curl=curl_init($URL);
curl_setopt($curl,CURLOPT_URL,$URL);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$resp=curl_exec($curl);
curl_close($curl);
$data=json_decode($resp);
$status=$data->status;
$massage=$data->message;
$msg="SENT";
}else{
    $msg="SENT";
}
}

};

if(isset($_POST['otp'])){
$phone=mysqli_real_escape_string($conn,$_POST['phone']);
$pass=mysqli_real_escape_string($conn,$_POST['pass']);   
$name=mysqli_real_escape_string($conn,$_POST['name']); 
$otp=mysqli_real_escape_string($conn,$_POST['otp']); 
$long=mysqli_real_escape_string($conn,$_POST['long']); 
$lat=mysqli_real_escape_string($conn,$_POST['lat']); 
$OTP=$_SESSION['SOTP'];
if($otp==$OTP){
  $sql="INSERT INTO `user` (`id`, `userphone`, `username`, `useraddress`, `city`, `userlandmark`, `latuser`, `longuser`, `addisset`, `wallet`, `auth`, `otp`) VALUES (NULL, '$phone', '$name', '', '', '', '$lat', '$long', '0', '0', '$pass', '$otp');";
$qry=mysqli_query($conn,$sql);
if($qry==true){
    
     $cookie_name="phone";
	    $cookie_value=$phone;
	    $domain=$_SERVER['SERVER_NAME'];
	    setcookie($cookie_name,$cookie_value,time()+(86400*365),"/$route",$domain);
		$_SESSION['login'] = $phone;
    
    header("location:index.php");
}  
}


};


  if(isset($_COOKIE['phone'])){
header("Location:location.php");}      
        
	?>



<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

   <title><?php echo  $appname; ?></title>
    <meta name="theme-color" content="<?php echo $k['theme']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
      <!-- Slick Slider -->
      <link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css"/>
      <link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css"/>
      <!-- Feather Icon-->
      <link href="vendor/icons/feather.css" rel="stylesheet" type="text/css">
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Sidebar CSS -->
      <link href="vendor/sidebar/demo.css" rel="stylesheet">
      <!-- Flag Mobile Number -->
      <link rel="stylesheet" href="vendor/build/css/intlTelInput.css">
      <link rel="stylesheet" href="vendor/build/css/demo.css">
      <style>
h2 {text-align: center;}
p {text-align: center;}

</style>
   </head>
   <body  onload="getLocation()">
      <div class="osahan-signup login-page" style="background:<?php echo $k['theme']; ?>" >
         <!--<video   loop autoplay muted id="vid" HEIGHT="800" >-->
         <!--   <source src="img/BGV.mp4" type="video/mp4">-->
         <!--   <source src="img/BGV.mp4" type="video/ogg">-->
         <!--   Your browser does not support the video tag.-->
         <!--</video>-->
        
         <div class="vh-100">
            <div class="p-4 login-page-form">
                <BR><BR>
                    
                
               <h2 class="text-<?php echo $k['btn-color']; ?> my-0" ><?php echo $appname;?></h2>
               <?php if($msg=="SENT"){  ?>
               
                <p class="text-<?php echo $k['btn-color']; ?> text-50 mt-3">OTP Sent to Your Mobile Number</p>
               <form class="mt-5 mb-4" action="register.php" method="POST">
                  <div class="form-group mb-3">
                     <input type="hidden" placeholder="Enter Your Name" name="name"  value="<?php echo $name; ?>" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                  
                  <div class="form-group mb-3">
                     <input type="hidden" placeholder="Enter Mobile Number" name="phone" value="<?php echo $phone; ?>" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                   <div class="form-group mb-3">
                     <input type="hidden" placeholder="Create a Password" name="pass" value="<?php echo $pass; ?>" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                  
                   <input type="hidden"  name="lat" value="<?php echo $lat; ?>">
                    <input type="hidden"  name="long" value="<?php echo $long; ?>">
                   <div class="form-group mb-3">
                     <input type="number" placeholder="Enter OTP" name="otp" value="<?php if($RESAPI['STATUS']=='DISABLE'){ echo $_SESSION['SOTP'];};?>" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                  
                  <button class="btn btn-primary btn-lg btn-block" type="submit"><a class="landing.html" class="font-decoration-none">Verify Now</a></button> </form>
               
               <?php }else{  ?>
               
                <p class="text-<?php echo $k['btn-color']; ?> text-50 mt-3">Sign up with your Mobile to continue</p>
               <form class="mt-5 mb-4" action="register.php" method="POST">
                  <div class="form-group mb-3">
                     <input type="text" placeholder="Enter Your Name" name="name" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                  
                  <div class="form-group mb-3">
                     <input type="number" placeholder="Enter Mobile Number" name="phone" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                   <div class="form-group mb-3">
                     <input type="text" placeholder="Create a Password" name="pass" class="form-control form-control-lg border-0" id="exampleInputNumber1" required >
                  </div>
                  <input type="hidden" name="otpsend" value="1">
                  <input type="hidden" id="lat" name="lat" value="">
                    <input type="hidden" id="long" name="long" value="">
                  
                  <button class="btn btn-<?php echo $k['btn-color']; ?> btn-lg btn-block" type="submit">Register</button> </form>
               <p class="text-center text-white"> <?php echo $msg;?></p>
               <?php }; ?>
              
                  <BR><BR><BR>
                  <p class="text-center text-<?php echo $k['btn-color']; ?>">Powered by : <?php echo $appname; ?> Pvt. Ltd.</p>
                  <!--<div class="mb-3">-->
                  <!--   <div class="row">-->
                  <!--      <div class="col-6 pr-1">-->
                  <!--         <button class="btn btn-lg btn-light btn-block">-->
                  <!--         <img src="img/facebook.svg" alt=""> Facebook-->
                  <!--         </button>-->
                  <!--      </div>-->
                  <!--      <div class="col-6 pl-1">-->
                  <!--         <button class="btn btn-lg btn-light btn-block">-->
                  <!--         <img src="img/search.svg" alt=""> Google-->
                  <!--         </button>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
              
            </div>
            <div class="new-acc fixed-bottom d-flex align-items-center justify-content-center p-3">
               
                  
               
            </div>
         </div>
      </div>
   
      
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- slick Slider JS-->
      <script type="text/javascript" src="vendor/slick/slick.min.js"></script>
      <!-- Sidebar JS-->
      <script type="text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>
      <!-- Flag Number-->
      <script src="vendor/build/js/intlTelInput.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="js/osahan.js"></script>
          <script type="text/javascript">
    function getLocation(){
      if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showPosition);
      }
    }
  function showPosition(position){
      document.getElementById('lat').value=position.coords.latitude;
      document.getElementById('long').value=position.coords.longitude;
    console.log(lat);
  }
  </script>
      
      
      
   </body>
</html>