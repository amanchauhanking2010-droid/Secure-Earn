<?php
include 'pay/db.php';
session_start();
if(!isset($_COOKIE['phone'])){
    header("Location:logout.php");
    exit;
}

$phone = $_COOKIE['phone'];



  $uid = $_GET['id'];
// Step 2: Fetch chat via cURL
$chat_url = "$base_url/get-chat.php?uid=$uid&admin_id=$admin_id";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $chat_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$chat_response = curl_exec($ch);
curl_close($ch);

$chat_data = json_decode($chat_response, true);

if (!isset($chat_data['status']) || $chat_data['status'] != 'success') {
    die("Error fetching chat data");
}

$chats = $chat_data['data'];

// Step 3: Display chats (similar to your HTML)
$k['theme'] = "#fcba03";
?>





<div style="width:250 ;height:500 ;background:light " class="mb-2">

<?php
 
foreach($chats as $res){
    $seen = $res['seen'];
    $type = $res['type'];
    $message = $res['message'];
    $date = $res['datandtime'];
    $url = $res['url'] ?? '';


?>
 
    <?php if($seen=='USER'){?>

 <div class="message-item user" >
            <div class="content">
                <div class="bubble text-right text-dark" style="background:<?php echo $k['theme']; ?>">
                   <?php echo $message;?>
                </div>
                <div class="footer text-light"> 
                <h6 style="font-size:7px; color:white;"> <?php echo $date;?></h6>
                </div>
            </div>
        </div>
  
    <?php }else{ ?>
    
    
   
    <div class="message-item">
         
            <div class="content">
                <!--<div class="title">Marry</div>-->


    <div class="bubble text-left">
       <?php echo nl2br($message); ?>
    </div>



                <div class="footer text-light">
                    <h6 style="font-size:7px; color:white;"> <?php echo $date;?></h6>
                    </div>
            </div>
        </div>
        
         <?php }; ?>
         
      <?php }; ?>
 </div>   
