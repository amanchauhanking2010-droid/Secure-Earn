<?php

include 'pay/db.php';
session_start();
if(!isset($_COOKIE['phone'])){
header("Location:logout.php");}  

$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}


$appname=$data['app_name'];
$customer_support_whatsapp=$data['customer_support_whatsapp'];
$customer_support_phone=$data['customer_support_phone'];
$ananya=$data['min_order_amount'];

$k['theme']=$data['theme_color'];
$k['btn-color']=$data['btn_color'];

$phone=$_COOKIE['phone'];

// Get user details
    $url = "$base_url/get-user-details.php?admin_id=$admin_id&phone=$phone";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
$data = json_decode($response, true);
if (isset($data['status']) && $data['status'] === 'success') {
    $uid = $data['data']['id'];
    $username = $data['data']['username'];
    $userphone = $data['data']['userphone'];

   
} else {
    echo "Error fetching user details";
}

 $cookie_name = "user_id";
    $cookie_value = $uid;
    $domain = $_SERVER['SERVER_NAME'];
    setcookie($cookie_name, $cookie_value, time() + (86400 * 365), "", $domain);


                       
                        
?>

<!doctype html>
<html lang="en">



<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    
        <title><?php echo  $appname; ?></title>
    <meta name="theme-color" content="<?php echo $ttt['theme']; ?>">
    <meta name="description" content="<?php echo $ttt['app_description']; ?>">
    <meta name="keywords" content="<?php echo $ttt['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $ttt['fav_icon']; ?>" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
   
             <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap" rel="stylesheet">
 <!-- Font Awesome CDN (latest) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

        
          <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0px;
        }
        
    </style>
    
    
    
    <style>
/*b {text-align: center;}*/
/*p {text-align: center;}*/
h3 {text-align: left;}
div {text-align: center;}

.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1050; /* higher than Bootstrap modal */
    display: flex;
    justify-content: center;
    align-items: center;
}

.modal-content-center {
    background: white;
    padding: 20px;
    border-radius: 10px;
    width: 80%;
    max-width: 300px;
    text-align: center;
}



.code-box {
    background: #1e1e1e;
    color: #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    font-family: monospace;
    white-space: pre-wrap;
    overflow-x: auto;
}

</style>


  <style>
        
         #loaderr {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            display: none;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
            border-width: 0.3em;
        }
        
        
     
    </style>

</head>

<body class="bg-light">



<div style="background:<?php echo $k['theme']; ?>" class="appHeader" >

      <div class="left">
                 <a href="javascript:;" class="headerButton" data-toggle="modal" data-target="#sidebarPanel" >
                <ion-icon name="menu-outline" style="color:<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
            </div>
                <div class="pageTitle font-weight-bold " style="color:<?php echo $k['btn-color']; ?>" >
                 <?php echo $appname; ?>
                </div>
                <div class="right">
            <a href="profile.php?uid=<?php echo $uid; ?>&lid=<?php echo $lid; ?>" class="headerButton">
                <ion-icon name="person-outline" style="color:<?php echo $k['btn-color']; ?>"></ion-icon>
            </a>
        </div>
    </div>
    
<style>
    .profile-card {
  background: white;
  border-radius: 15px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  transition: transform .2s;
}

.profile-card:hover {
  transform: scale(1.02);
}

.status-dot {
  height: 10px;
  width: 10px;
  display: inline-block;
  border-radius: 50%;
  margin-left: 8px;
}

.online {
  background: #28a745;
}

.offline {
  background: #dc3545;
}

.text-muted {
  font-size: 14px;
}

</style>
    <!-- App Capsule -->
    <div id="appCapsule">


 <div class="container mt-3 mb-4">

  <!-- Profile Card 1 -->
  <a href="chat-room.php">
  <div class="profile-card d-flex align-items-center p-2 mb-3 rounded shadow-sm">
    <div class="profile-img">
      <img src="https://randomuser.me/api/portraits/women/11.jpg" class="rounded-circle" width="80" height="80">
    </div>
    <div class="profile-info text-left ml-3 flex-grow-1">
      <h5 class="mb-1 font-weight-bold">Priya Sharma <span class="status-dot online"></span></h5>
      <p class="mb-1 text-muted">📍 Mumbai, India</p>
      <p class="mb-0"><i class="fa fa-heart text-danger"></i> Speaks Hindi , English</p>
    </div>
  </div></a>

 
<a href="chat-room.php">
  <!-- Profile Card 3 -->
  <div class="profile-card d-flex align-items-center p-2 mb-3 rounded shadow-sm">
    <div class="profile-img">
      <img src="https://randomuser.me/api/portraits/women/18.jpg" class="rounded-circle" width="80" height="80">
    </div>
    <div class="profile-info text-left ml-3 flex-grow-1">
      <h5 class="mb-1 font-weight-bold">Ankita Das <span class="status-dot online"></span></h5>
      <p class="mb-1 text-muted">📍 Kolkata, India</p>
      <p class="mb-0"><i class="fa fa-heart text-danger"></i> Speaks - Hindi, Bengali, English</p>
    </div>
  </div></a>


<a href="chat-room.php">
  <!-- Profile Card 5 -->
  <div class="profile-card d-flex align-items-center p-2 mb-3 rounded shadow-sm">
    <div class="profile-img">
      <img src="https://randomuser.me/api/portraits/women/20.jpg" class="rounded-circle" width="80" height="80">
    </div>
    <div class="profile-info text-left ml-3 flex-grow-1">
      <h5 class="mb-1 font-weight-bold">Nisha Verma <span class="status-dot offline"></span></h5>
      <p class="mb-1 text-muted">📍 Pune, India</p>
      <p class="mb-0"><i class="fa fa-heart text-danger"></i>Speaks - Hindi, Bengali, English</p>
    </div>
  </div></a>


<a href="chat-room.php">
  <!-- Profile Card 7 -->
  <div class="profile-card d-flex align-items-center p-2 mb-3 rounded shadow-sm">
    <div class="profile-img">
      <img src="https://randomuser.me/api/portraits/women/25.jpg" class="rounded-circle" width="80" height="80">
    </div>
    <div class="profile-info text-left ml-3 flex-grow-1">
      <h5 class="mb-1 font-weight-bold">Sneha Gupta <span class="status-dot online"></span></h5>
      <p class="mb-1 text-muted">📍 Hyderabad, India</p>
      <p class="mb-0"><i class="fa fa-heart text-danger"></i>Speaks - Hindi, English</p>
    </div>
  </div></a>


<a href="chat-room.php">
  <!-- Profile Card 9 -->
  <div class="profile-card d-flex align-items-center p-2 mb-3 rounded shadow-sm">
    <div class="profile-img">
      <img src="https://randomuser.me/api/portraits/women/30.jpg" class="rounded-circle" width="80" height="80">
    </div>
    <div class="profile-info text-left ml-3 flex-grow-1">
      <h5 class="mb-1 font-weight-bold">Ritika Bose <span class="status-dot online"></span></h5>
      <p class="mb-1 text-muted">📍 Chennai, India</p>
      <p class="mb-0"><i class="fa fa-heart text-danger"></i> Speaks - Hindi, Bengali, English</p>
    </div>
  </div></a>

 

</div>

    
    
    </div>
    
    
      <div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">

                    <!-- profile box -->
                    <div style="background:<?php echo $k['theme']; ?>"  class="profileBox">
                        <div class="image-wrapper">
                             <img src="https://www.awms-system.com/website/wp-content/uploads/2021/05/persone-al-centro.gif" alt="logo" width="50" height="50" class="rounded-circle border-dark">
                        </div>
                        <div class="in">
                            <?php
                            if(isset($_COOKIE['phone'])){
                            ?>
                             <strong class="text" style="color:<?php echo $k['btn-color']; ?>;"><i><?php echo $username?></i></strong>
                             <p class="text" style="color:<?php echo $k['btn-color']; ?>;">+91-<?php echo $phone?></p><?php }else{ ?>
                            <a href="index.php"> <button onclick="example1()" type="button" class="btn btn-dark btn-sm">Please Login</button></a>
                             <?php };?>
                        </div>
                        <p class="mt-0 mb-0" onclick="example1()"> 
                        <a href="javascript:;" class="close-sidebar-button" data-dismiss="modal">
                            <ion-icon name="close" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                        </a></p>
                    </div>
                    <!-- * profile box -->

                    <ul class="listview flush transparent no-line image-listview mt-2">
                        <li>
                            
                            <a href="home.php?lid=<?php echo $lid;?>" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="home-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                 
                                <div class="in">
                                    Home
                                </div>
                                
                            </a>
                        </li>
                        
                       
                     
                        <li>
                            <div class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="moon-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                <div class="in">
                                    <div>Dark Mode</div>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input dark-mode-switch"
                                            id="darkmodesidebar">
                                        <label class="custom-control-label" for="darkmodesidebar"></label>
                                    </div>
                                </div>
                            </div>
                        </li>
                  
                       <li>
                            <a href="about.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                   About Us
                                </div>
                            </a>
                        </li>
                         <li>
                            <a href="privacy-policy.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Privacy Policy
                                </div>
                            </a>
                        </li>
                        
                          <li>
                            <a href="terms.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Terms & Conditions
                                </div>
                            </a>
                        </li>
                        
                         <li>
                            <a href="delete-policy.php" class="item">
                                <div style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="copy-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                                </div>
                                <div class="in">
                                  Account Delete Policy
                                </div>
                            </a>
                        </li>
                     
                      
                   
                        
                        <li>
                            <a href="logout.php" class="item">
                                <div  style="background:<?php echo $k['theme']; ?>"  class="icon-box">
                                    <ion-icon name="log-out-outline" style="color:<?php echo $k['btn-color']; ?>;"></ion-icon>
                                </div>
                                <div class="in">
                                    Logout
                                </div>
                            </a>
                        </li>
                    </ul>
                <!-- sidebar buttons -->
                <div style="background:<?php echo $k['theme']; ?>" class="sidebar-buttons">
                  
                    <a href="tel:+91<?php echo $customer_support_phone;?>" class="button">
                        <ion-icon name="call-outline" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                    </a>
                    <a href="https://api.whatsapp.com/send?phone=91<?php echo $customer_support_whatsapp;?>" class="button">
                        <ion-icon name="logo-whatsapp" color="<?php echo $k['btn-color']; ?>"></ion-icon>
                    </a>
                
                </div>
                <!-- * sidebar buttons -->
                    
                
            </div>
        </div>
    </div>
    </div>
    <!-- * chat footer -->

    <!-- ///////////// Js Files ////////////////////  -->
  <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
<script src="assets/js/lib/popper.min.js"></script>
<script src="assets/js/lib/bootstrap.min.js"></script>
<script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
<script src="assets/js/base.js"></script>



</body>

</html>
 
