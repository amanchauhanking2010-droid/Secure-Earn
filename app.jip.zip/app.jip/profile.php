<?php
session_start();
include 'pay/db.php';
if(!isset($_COOKIE['phone'])){
    header("location:index.php");
}

$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}


$appname=$data['app_name'];
$customer_support_whatsapp=$data['customer_support_whatsapp'];
$customer_support_phone=$data['customer_support_phone'];
$ananya=$data['min_order_amount'];

$k['theme']=$data['theme_color'];
$k['btn-color']=$data['btn_color'];

$phone=$_COOKIE['phone'];

// Get user details
    $url = "$base_url/get-user-details.php?admin_id=$admin_id&phone=$phone";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
$data = json_decode($response, true);
if (isset($data['status']) && $data['status'] === 'success') {
    $uid = $data['data']['id'];
    $username = $data['data']['username'];
    $userphone = $data['data']['userphone'];

   
} else {
    echo "Error fetching user details";
}



 $country = 'IN'; // Change this dynamically based on user location or preference

// Comprehensive list of countries with their dialing codes

        $ip_address = $_SERVER['REMOTE_ADDR'];
$ch = curl_init('http://ip-api.com/json/'.$ip_address);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response1 = curl_exec($ch);
curl_close($ch);
$data1 = json_decode($response1, true);

if ($data1['status'] == 'success') {
    // Output the geolocation data
    $IP=$data1['query'];
    $Location=$data1['city'];
    $Address=$data1['zip'];
    $State=$data1['regionName'];
    $Country=$data1['country'];
    $Latitude=$data1['lat'];
    $Longitude=$data1['lon'];
} else {
    $IP="";
    $Location="";
    $Address="";
    $State="";
    $Country="";
    $Latitude="";
    $Longitude="";
}
$full_add=$Location.', '.$State.', '.$Country.', '.$Address;

if(!isset($_COOKIE['phone'])){
  header("location:logout.php");   
}
?>


<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo  $appname; ?></title>
    <meta name="theme-color" content="<?php echo $k['theme']; ?>">
    <meta name="description" content="<?php echo $k['app_description']; ?>">
    <meta name="keywords" content="<?php echo $k['app_tag']; ?>" />
    <link rel="icon" type="image/png" href="../admin/<?php echo $k['fav_icon']; ?>" sizes="32x32">
<!-- Leaflet Map CSS and JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
     <style>.goog-te-banner-frame.skiptranslate {
    display: none !important;
    } 
body {
    top: 0px !important; 
    }</style>
    
    <script type="text/javascript">
          function example1() {
             // Vibrate for 500ms
             navigator.vibrate([60]);
          }
        </script> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap" rel="stylesheet">   
</head>

<body style="font-family: 'Montserrat', sans-serif;">

  <!--<div id="loader">-->
  <!--      <img src="sadmin/images/<?php echo  $applogo; ?>" alt="logo" width="220" height="50">-->
        <!--<div class="spinner-grow text-warning" role="status"></div>-->
  <!--  </div>-->

    <!-- App Header -->


    

<div style="background:<?php echo $k['theme']; ?>"  class="appHeader" >

        <div class="left">
             <p class="mt-0 mb-0" onclick="example1()">
            <a href="home.php?lid=<?php echo $_GET['lid']; ?>" class="headerButton" >
                <ion-icon name="chevron-back-outline"  color="<?php echo $k['btn-color']; ?>"></ion-icon>
            </a></p>
        </div>
        <div class="pageTitle text-<?php echo $k['btn-color']; ?>"> <?php if(strlen($name)>4){ echo 'My Profile'; }else{ echo 'Complete your Profile';} ;?></div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

<div class="ml-2 mr-2 mt-3">
  
</div>
 

        <div class="section full mt-2 mb-2">
            
            <div class="wide-block pb-1 pt-2">
               
                
                <!--<?php print_r($response);  echo "Admin id: $admin_id"; echo "url: $url";?>-->

                <form class= "myForm" action="profile-update.php" method="POST">
                    <div class="form-group boxed">
                        <div class="input-wrapper">
                            <label class="label" for="name5">Name <?php echo $uid;?></label>
                            <input type="text" class="form-control" name="name" value="<?php echo $username;?>"placeholder="Enter your name" required>
                            
                            <i class="clear-input">
                                <ion-icon name="close-circle"></ion-icon>
                            </i>
                            
                        </div>
                    </div>

                   

                    
                    

                    <div class="form-group boxed">
                        <div class="input-wrapper">
                            <label class="label" for="phone5">Phone</label>
                            <input  type="tel" class="form-control" name="phone" value="<?php echo $phone;?>" placeholder="Enter your phone number" readonly>
                            <i class="clear-input">
                                <ion-icon name="close-circle"></ion-icon>
                            </i>
                        </div>
                    </div>

                    <div class="form-group boxed">
                        <div class="input-wrapper">
                            <label class="label" >Address</label>
                            <input type="text" name="address" value="<?php echo $full_add;?>"  class="form-control" placeholder="Add your address" required>
                            <i class="clear-input">
                                <ion-icon name="close-circle"></ion-icon>
                            </i>
                        </div>
                    </div>
                
                    
                  
                   <input type="hidden" name="admin_id" value="<?php echo $admin_id;?>" >
                   <input type="hidden" name="uid" value="<?php echo $uid;?>" >
                  
                    
                   <div id="map" style="height: 250px; width: 100%; border-radius:30px;"></div>

            
            <div class="form-button-group">
                 <button onclick="example1()" type="submit" class="btn btn-secondary btn-block btn-lg">Update Profile</button></form>
            </div>
        </div>
                
                
            </div>
        </div>


       
        </div>




    </div>
    <!-- * App Capsule -->

    

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Jquery -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <!-- Bootstrap-->
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
    <!-- Owl Carousel -->
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <!-- jQuery Circle Progress -->
    <script src="assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>
    <script>
    // Get the file input and profile picture elements
    const fileInput = document.getElementById('image');
    const profilePic = document.getElementById('profile-pic');

    // Add event listener to the profile picture
    profilePic.addEventListener('click', function() {
        // Trigger the file input click event
        fileInput.click();
    });
</script>


  
<script>
    const initialLat = <?php echo $lat ?: 22.5726; ?>;
    const initialLng = <?php echo $long ?: 88.3639; ?>;

    const map = L.map('map').setView([initialLat, initialLng], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    const marker = L.marker([initialLat, initialLng], { draggable: true }).addTo(map);

    marker.on('dragend', function (e) {
        const position = marker.getLatLng();
        console.log("New position:", position.lat, position.lng);
        // You can send this data to backend via AJAX if needed
    });
</script>

  

<script type="text/javascript" src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

</body>

</html>