<?php

include 'pay/db.php';
session_start();
if(!isset($_COOKIE['phone'])){
header("Location:logout.php");}  

$url = "$base_url/get-admin-details.php?admin_id=$admin_id"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

// Decode the JSON
$result = json_decode($response, true);

// Check and extract
if($result['status'] === 'success'){
    $data = $result['data'];
   
} else {
    echo "Error: " . $result['message'];
}
//print_r($data);

//echo $phone=$_COOKIE['phone'];
//echo $admin_id;
// Get user details

    $url = "$base_url/get-user-details.php?admin_id=$admin_id&phone=$phone";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
$data = json_decode($response, true);

// print_r($data);

if (isset($data['status']) && $data['status'] === 'success') {
   echo $uid = $data['data']['id'];
   $username = $data['data']['username'];
   $userphone = $data['data']['userphone'];

   
} else {
    echo "Error fetching user details";
}



// $uid=$_COOKIE['user_id'];

$room = $admin_id;
set_time_limit(60);
date_default_timezone_set('Asia/Kolkata');


$chat = $_POST['msg'];
$dateandtime = date("Y-m-d H:i:s"); // better format

// URL-encode variables
$chat_encoded = urlencode($chat);
$date_encoded = urlencode($dateandtime);

$url = "$base_url/add-chat.php?admin_id=$admin_id&uid=$uid&msg=$chat_encoded&date=$date_encoded";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);

if(curl_errno($ch)){
    echo "cURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

echo "API Response: " . $response;

echo "Admin id: ".$admin_id.'<br>';
echo "uid: ".$uid.'<br>';
echo "chat: ".$chat_encoded.'<br>';
$answer=$response;

sleep(rand(1, 4)); // wait 1 to 4 seconds randomly

//mysqli_query($conn, "INSERT INTO `chat` (`user_id`, `room`, `message`, `seen`, `datandtime`) VALUES ('$uid', '$room', '$answer', 'ADMIN', '$dateandtime')");


echo "SENT";
?>